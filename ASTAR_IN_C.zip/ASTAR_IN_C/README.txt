I implemented A* algorithm in C FINALLYY, took me a while.
If you want to try out a new map, change the map.txt file (1s represent untraversable area, 0s represent traversable area).
I have set the size currently as 8 x 8.

In the path visualization shown in the end '#' represents walls, '*' represents traversable area, '.' represents actual path.

To test it simply compiler and run the code.
(Note:- if you are using vs code, sometimes it can't find the map.txt file because vs code checks in the home directory i think so better use gcc or any other compiler)
